# Rhythm Warfare - Level 01 MIDI draft

Original starter arrangement: **174 BPM, 4/4, C# minor, 64 bars**.
Length at exactly 174 BPM: **88.27586 seconds** (about 1:28).
This pack contains MIDI and authoring data only; you supply all sounds and WAV exports.
No commercial song, sample, plugin preset, or prior MIDI pack was used as a source.

## Files

- `01_Kick.mid`: 138 note-ons, MIDI note 36, channel 10.
- `02_Snare.mid`: 111 note-ons, MIDI note 38, channel 10.
- `03_Bass.mid`: 72 monophonic notes, channel 1; 38 holds and 34 taps.
- `Player_Chart_Fragment.json`: the corresponding player chart and music timing metadata.
- `Authoring_Manifest.json`: filenames, interpretation rules and production totals.
- `Validation_Report.txt`: checks on the written MIDI bytes and chart.

The chart fragment is not a complete game level. The developer must merge in the
level ID, rules, four final audio paths, battlefield, roster and enemy schedule.
The current MIDI-to-chart mapping is specific to this pack, not a new universal game rule.

## Bring the MIDI into Ableton

1. Set the project to 174 BPM and 4/4. Import each MIDI on its own track.
2. All three source files start at bar 1, beat 1 and end at the start of bar 65.
   Place them at the same timeline origin. If an import crops leading silence,
   correct its placement: kick first note = 1.1.1; snare first note = 5.2.1;
   bass first note = 9.1.1. Do not move those first notes to the same beat.
3. Load a kick sound responding to MIDI note 36 and a snare sound responding to
   MIDI note 38. Drum Rack/Simpler or your preferred drum synth is suitable.
   Only one drum pad needs a sample on each track. MIDI numbers are authoritative
   if your software labels octave names differently.
4. Load a bass instrument, for example Pigments or Omnisphere, on the bass track.
   A short-release mono bass patch is a useful starting point. Its written pitches
   are musical; pitch does not select different gameplay lanes. Do not add extra
   bass note-ons to create synth layering: duplicate audio voices inside the patch
   or group the instrument layers while keeping the original chart source.
5. Add pads, chords, leads, hats, percussion and FX on your own Other tracks.
   The existing drum and bass rhythm is intentionally fixed to the supplied chart.
   If you change rhythm or note lengths, regenerate the player chart from the revised MIDI.
6. Avoid timing-shifting MIDI effects, grooves or processing that moves the
   audible attacks away from the chart. A naturally slow attack may also need
   adjustment. Audio/chart alignment must be checked with the final sounds.

The MIDI contains no program changes or plugin-specific preset data. It uses SMF
type 1 with a conductor track, phrase markers, 960 ticks per beat, and no swing.
The MIDI tempo is rounded to 344828 microseconds per quarter note, as required by
the MIDI file format; its total difference from exact 174 BPM is about 0.11 ms.

## Arrangement

| Bars | Section | Kick taps | Snare taps | Bass actions |
| --- | --- | ---: | ---: | ---: |
| 1-8 | Intro / learn the drums | 16 | 8 | 0 |
| 9-16 | Bass introduction / build | 16 | 16 | 8 |
| 17-32 | First drop | 40 | 32 | 24 |
| 33-40 | Breakdown / rebuild | 8 | 8 | 4 |
| 41-56 | Second drop | 40 | 32 | 24 |
| 57-64 | Finale / resolution | 18 | 15 | 12 |
| **Total** | | **138** | **111** | **72** |

Bars 1-4 teach kick; bars 5-8 add snare. Bass enters at bar 9.
Bars 33-36 leave space for a melodic breakdown; drums return at bar 37.
The second drop adds bass octave variation. The final bar resolves to C# minor
and leaves the last half-bar for the ending to decay.

## Optional chords for Other

Use these as a starting point for your own musical layers. No chord MIDI is included.

| Bars | Chords |
| --- | --- |
| 1-8 | C#m atmosphere / pedal |
| 9-16 | C#m, A, E, G#7; two bars each |
| 17-32 | C#m, A, E, B; two bars each, repeat twice |
| 33-40 | C#m, A, E, B; two bars each |
| 41-56 | C#m, A, E, B; two bars each, repeat twice |
| 57-62 | C#m, A, E; two bars each |
| 63 | G#7 |
| 64 | C#m |

Basic chord tones: C#m = C# E G#; A = A C# E; E = E G# B;
B = B D# F#; G#7 = G# B# D# F# (B# is the same piano key as C).
Place Other chords in a higher register so they support the bass rather than
duplicating its low layer. Hats and risers can supply energy without adding input lanes.

## Export four WAV stems

Export the same range for every stem: bar 1 to the start of bar 65, exactly 64 bars.
Use the same sample rate and bit depth for all four; 48 kHz / 24-bit PCM is a
practical starting choice. Preserve leading silence, export without independent
normalisation, and keep a safe level when all four are summed.

- `audio/01_Kick.wav`: all kick layers and their effects.
- `audio/02_Snare.wav`: all snare layers and their effects.
- `audio/03_Bass.wav`: all bass layers and their effects.
- `audio/04_Other.wav`: your remaining musical layers and their effects.

Keep kick/snare/bass out of Other, including mixed drum breaks and FX returns.
Review shared dynamics and sidechain routing so the exports recombine as intended.
Listen to all stems together, then remove each production stem separately.
Do not trim each WAV independently. If the ending needs more room, extend all four
exports together and update the level duration; keep the chart and section coverage consistent.
No rendered sound is supplied or auditioned in this pack, so final patch choice,
mix quality and audible alignment still need your review.

## MIDI-to-chart rules for the developer

- Kick/snare: each positive-velocity note-on is a tap. Ignore their note lengths.
- Bass: notes shorter than 480 ticks are taps; notes of 480 ticks or
  longer are holds. The supplied taps are 240 ticks long. All supplied holds
  are at least 960 ticks. Hold duration is note-off minus note-on and the reward
  resolves at the scheduled tail after a successful hold.
- One note-on gives one input event. Velocity and pitch never multiply rewards.
- Read the files by lane, not their MIDI channels alone: kick and snare both use
  the standard drum channel. Retain their absolute offsets from bar 1.
- The three MIDIs are the source of truth for player timing, not a placement sheet.
- `Player_Chart_Fragment.json` is a reference conversion, not an extra chart to
  append to the MIDI import. The two representations describe the same events.
- Do not generate an event from MIDI note-off messages or zero-velocity note-ons.
- All prompts are on a fixed grid. No kick and snare taps coincide, so a bass
  hold can coexist with the drum inputs without requiring three simultaneous touches.

## Production and implementation handoff

With every ground producer alive and every note successful across the full song,
the chart awards **138 tanks and 555 infantry**, plus
**72 bass actions** subject to the air rules. The live air limit remains
five aircraft. These ground totals are cumulative production before combat deaths,
not a count of simultaneous survivors. They exceed the earlier suggested 40/150
estimate; do not cap or discard successful production to fit that estimate.

The enemy schedule must be separately authored and tested against these player
events. Music-file validation does not establish combat balance or prove the level
is winnable. Use placeholder sounds while the final four WAV stems are being made.
